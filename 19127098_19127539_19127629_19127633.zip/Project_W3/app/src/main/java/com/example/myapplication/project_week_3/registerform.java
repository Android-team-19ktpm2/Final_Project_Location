package com.example.myapplication.project_week_3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.sql.Date;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

public class registerform extends AppCompatActivity  implements DatePickerDialog.OnDateSetListener {
    EditText txtUsername,txtPassword, txtRetype,txtBirthdate;
    Button btnSelect,btnReset,btnSignup;
    RadioButton rdMale;
    RadioButton rdFemale;
    CheckBox ckTennis,ckFutbal,ckOthers;
    DatePickerDialog datePicker;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerform);
//        initDatePicker();
        setControls();
        setEvents();




        btnSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Please note that use your package name here
                com.example.myapplication.project_week_3.DatePicker mDatePickerDialogFragment;
                mDatePickerDialogFragment = new com.example.myapplication.project_week_3.DatePicker();
                mDatePickerDialogFragment.show(getSupportFragmentManager(), "DATE PICK");
            }
        });
    }
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        month = month+1;
        String selectedDate = "";
        if (month<10){
            selectedDate = dayOfMonth+"/0"+month+"/"+year;
        }else {
            selectedDate = dayOfMonth+"/"+month+"/"+year;
        }

        txtBirthdate.setText(selectedDate);
    }

    private void setEvents() {

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtUsername.setText("");
                txtPassword.setText("");
                txtRetype.setText("");
                txtBirthdate.setText("");

                rdMale.setChecked(false);
                rdFemale.setChecked(false);
                ckTennis.setChecked(false);
                ckFutbal.setChecked(false);
                ckOthers.setChecked(false);
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Check()==false){
                    Toast.makeText(registerform.this,"Some fields are missing",Toast.LENGTH_LONG).show();
                }
                else{
                    if(isValidFormat("dd/MM/yyyy",txtBirthdate.getText().toString(),Locale.ENGLISH)){
                        if (txtPassword.getText().toString().equals(txtRetype.getText().toString())){
                            Intent intent = new Intent(getBaseContext(), resultform.class);

                            intent.putExtra("USER_NAME", txtUsername.getText().toString());
                            intent.putExtra("PASS_WORD", txtPassword.getText().toString());
                            intent.putExtra("BIRTHDATE", txtBirthdate.getText().toString());


                            System.out.println(rdFemale.getText().toString());
                            if (rdFemale.isChecked()){
                                intent.putExtra("GENDER","Female");
                            }else if (rdMale.isChecked()){
                                intent.putExtra("GENDER","Male");
                            }

                            String hobbies="";
                            if(ckFutbal.isChecked()){
                                hobbies+= "Futbal";
                            }
                            if(ckTennis.isChecked()){
                                hobbies+=  ", Tennis";
                            }
                            if(ckOthers.isChecked()){
                                hobbies+= ", Others";
                            }
                            intent.putExtra("HOBBIES", hobbies);

                            startActivity(intent);
                            finish();
                        }else {
                            Toast.makeText(registerform.this,"Wrong Retype",Toast.LENGTH_LONG).show();
                        }
                    }else {
                        Toast.makeText(registerform.this,"Wrong Type Day",Toast.LENGTH_LONG).show();
                    }

                }
            }
        });
    }

    private void setControls() {
        txtUsername = (EditText) this.findViewById(R.id.txtUsername);
        txtPassword = (EditText) this.findViewById(R.id.txtPassword);
        txtRetype = (EditText) this.findViewById(R.id.txtRetype);
        txtBirthdate = (EditText) this.findViewById(R.id.txtBirthdate);
        rdFemale = (RadioButton) this.findViewById(R.id.rdFemale) ;
        rdMale = (RadioButton) this.findViewById(R.id.rdMale);
        ckTennis = (CheckBox) this.findViewById(R.id.ckTennis);
        ckOthers = (CheckBox) this.findViewById(R.id.ckOthers);
        ckFutbal = (CheckBox) this.findViewById(R.id.ckFutbal);
        btnReset = (Button) this.findViewById(R.id.btnReset);
        btnSelect = (Button) this.findViewById(R.id.btnSelect);
        btnSignup = (Button) this.findViewById(R.id.btnSignup);
    }

    private boolean Check() {

        if (txtBirthdate.getText().toString().equals(""))
            return false;
        if (txtPassword.getText().toString().equals(""))
            return false;
        if (txtUsername.getText().toString().equals(""))
            return false;
        return true;
    }

    public static boolean isValidFormat(String format, String value,  Locale locale) {
        LocalDateTime ldt = null;
        DateTimeFormatter fomatter = DateTimeFormatter.ofPattern(format, locale);

        try {
            ldt = LocalDateTime.parse(value, fomatter);
            String result = ldt.format(fomatter);
            return result.equals(value);
        } catch (DateTimeParseException e) {
            try {
                LocalDate ld = LocalDate.parse(value, fomatter);
                String result = ld.format(fomatter);
                return result.equals(value);
            } catch (DateTimeParseException exp) {
                try {
                    LocalTime lt = LocalTime.parse(value, fomatter);
                    String result = lt.format(fomatter);
                    return result.equals(value);
                } catch (DateTimeParseException e2) {
                    // Debugging purposes
                    //e2.printStackTrace();
                }
            }
        }

        return false;

    }
}