package com.example.myapplication.project_week_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class resultform extends AppCompatActivity {


    TextView txtUsername,txtPassword,txtBirthdate,txtGender,txtHobbies;
    Button btnExit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultform);
        setControls();
        setEvens();
    }

    private void setEvens() {
        String Username = getIntent().getStringExtra("USER_NAME");
        String Password = getIntent().getStringExtra("PASS_WORD");
        String Gender = getIntent().getStringExtra("GENDER");
        String Birthdate = getIntent().getStringExtra("BIRTHDATE");
        String Hobbies = getIntent().getStringExtra("HOBBIES");


        txtHobbies.setText(Hobbies);
        txtUsername.setText(Username);
        txtBirthdate.setText(Birthdate);
        txtGender.setText(Gender);
        txtPassword.setText(Password);

    }

    private void setControls() {
        btnExit = findViewById(R.id.btnExit);
        txtUsername = findViewById(R.id.txtUsername);
        txtPassword = findViewById(R.id.txtPassword);
        txtBirthdate = findViewById(R.id.txtBirthdate);
        txtGender = findViewById(R.id.txtGender);
        txtHobbies = findViewById(R.id.txtHobbies);
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(1);
            }
        });
    }
}